# Welcome to My Nba Game Analysis
***

## Task
The problem involves creating two functions, analyse_nba_game and print_nba_game_stats, to process NBA game data and generate a summary and formatted statistics,
 respectively.

The challenge of the task lies in several key areas that require careful handling and implementation:

Data Parsing and Extraction: Parsing the play-by-play data accurately is crucial. Each play contains multiple pieces of information (period, time remaining, teams involved, scores, play description) that need to be correctly extracted and processed. Handling variations in input formats and ensuring robust parsing logic is implemented can be challenging.

Data Structure and Organization: Once the data is parsed, structuring and organizing it into a meaningful format (such as dictionaries and lists) for further analysis and output is essential. This involves correctly mapping plays to teams, updating scores dynamically, and aggregating player statistics accurately.

Statistical Calculations: Calculating player statistics like field goals made and attempted, three-pointers made and attempted, free throws made and attempted, as well as shooting percentages (FG%, 3P%, FT%), requires meticulous counting and calculation. Handling scenarios where a player might have zero attempts in a category (e.g., no three-point attempts) without causing errors or inaccuracies is challenging.

Handling Game Events and Edge Cases: Managing various game events such as turnovers, rebounds, fouls, and free throw situations requires careful event detection and appropriate updates to game state and player statistics. Edge cases such as simultaneous events or rapid succession of plays need to be managed to avoid data inconsistencies.

Output Formatting: Once statistics are calculated, formatting them in a clear, readable manner for output (as specified in the print_nba_game_stats function) involves careful alignment and presentation. Ensuring that player names and statistics align correctly in columns and that totals are accurately calculated and displayed adds to the challenge.

Testing and Validation: Comprehensive testing across different game scenarios and edge cases is essential to verify that the functions (analyse_nba_game and print_nba_game_stats) handle all expected inputs correctly and produce accurate outputs. Testing helps identify and address bugs, edge cases, and performance issues.

## Description
To solve the problem of analyzing NBA game data and generating statistics, here's a structured approach I would take:

Data Parsing and Extraction
Game Analysis and Statistics Calculation
Player Statistics Calculation
Output Formatting
Testing and Validation

## Installation
Treate the Main Program Files
nba_analysis/analysis.py?
nba_analysis/print_stats.py
Create Test Files
tests/test_analysis.py

## Usage
works by analyzing a sequence of play-by-play moves from an NBA game and generating a summary of statistics for each player.
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
