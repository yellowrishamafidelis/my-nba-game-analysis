import re
from collections import defaultdict

def analyse_nba_game(play_by_play_moves):
    team_data = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    teams = {}
    
    for move in play_by_play_moves:
        fields = move.split('|')
        period, remaining_sec, relevant_team, away_team, home_team, away_score, home_score, description = fields
        away_score, home_score = int(away_score), int(home_score)
        
        if " makes " in description:
            player = re.search(r"([A-Z]\. [A-Z][a-z]+)", description).group(0)
            if "3-pt" in description:
                team_data[relevant_team][player]["3P"] += 1
                team_data[relevant_team][player]["3PA"] += 1
                team_data[relevant_team][player]["PTS"] += 3
            elif "2-pt" in description:
                team_data[relevant_team][player]["FG"] += 1
                team_data[relevant_team][player]["FGA"] += 1
                team_data[relevant_team][player]["PTS"] += 2
            elif "free throw" in description:
                team_data[relevant_team][player]["FT"] += 1
                team_data[relevant_team][player]["FTA"] += 1
        
        elif " misses " in description:
            player = re.search(r"([A-Z]\. [A-Z][a-z]+)", description).group(0)
            if "3-pt" in description:
                team_data[relevant_team][player]["3PA"] += 1
            elif "2-pt" in description:
                team_data[relevant_team][player]["FGA"] += 1
            elif "free throw" in description:
                team_data[relevant_team][player]["FTA"] += 1
        
        elif "Turnover by " in description:
            player = re.search(r"Turnover by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["TOV"] += 1
        
        elif "Offensive rebound by " in description:
            player = re.search(r"Offensive rebound by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["ORB"] += 1
        
        elif "Defensive rebound by " in description:
            player = re.search(r"Defensive rebound by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["DRB"] += 1
        
        elif "Assist by " in description:
            player = re.search(r"Assist by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["AST"] += 1
        
        elif "Block by " in description:
            player = re.search(r"Block by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["BLK"] += 1
        
        elif "Steal by " in description:
            player = re.search(r"Steal by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["STL"] += 1
        
        elif "foul by " in description:
            player = re.search(r"foul by ([A-Z]\. [A-Z][a-z]+)", description).group(1)
            team_data[relevant_team][player]["PF"] += 1
        
        if relevant_team not in teams:
            teams[relevant_team] = relevant_team
            teams[away_team] = away_team
            teams[home_team] = home_team
    
    result = {
        "home_team": {"name": home_team, "players_data": []},
        "away_team": {"name": away_team, "players_data": []},
    }
    
    for team, players in team_data.items():
        for player, stats in players.items():
            stats["TRB"] = stats["ORB"] + stats["DRB"]
            stats["FG%"] = round((stats["FG"] / stats["FGA"]) * 100, 1) if stats["FGA"] else 0
            stats["3P%"] = round((stats["3P"] / stats["3PA"]) * 100, 1) if stats["3PA"] else 0
            stats["FT%"] = round((stats["FT"] / stats["FTA"]) * 100, 1) if stats["FTA"] else 0
            stats["player_name"] = player
            team_side = "home_team" if team == home_team else "away_team"
            result[team_side]["players_data"].append(stats)
    
    return result

def print_nba_game_stats(team_dict):
    headers = ["Players", "FG", "FGA", "FG%", "3P", "3PA", "3P%", "FT", "FTA", "FT%", "ORB", "DRB", "TRB", "AST", "STL", "BLK", "TOV", "PF", "PTS"]
    header_str = '\t'.join(headers)
    print(header_str)
    
    for team_key in ["home_team", "away_team"]:
        team = team_dict[team_key]
        players_data = team["players_data"]
        
        totals = defaultdict(int)
        for player_stats in players_data:
            row = [player_stats["player_name"]]
            for key in headers[1:]:
                value = player_stats.get(key, 0)
                if isinstance(value, float):
                    row.append(f'{value:.1f}')
                else:
                    row.append(str(value))
                totals[key] += value
            print('\t'.join(row))
        
        totals_row = ["Totals"]
        for key in headers[1:]:
            value = totals[key]
            if "FG%" in key or "3P%" in key or "FT%" in key:
                totals_row.append(f'{value:.1f}')
            else:
                totals_row.append(str(value))
        print('\t'.join(totals_row))

# Example usage
play_by_play_moves = [
    "1|708.00|GOLDEN_STATE_WARRIORS|OKLAHOMA_CITY_THUNDER|GOLDEN_STATE_WARRIORS|0|0|Turnover by K. Thompson (bad pass; steal by S. Adams)",
    "1|703.00|OKLAHOMA_CITY_THUNDER|OKLAHOMA_CITY_THUNDER|GOLDEN_STATE_WARRIORS|0|0|Turnover by P. George (bad pass)",
    "1|691.00|GOLDEN_STATE_WARRIORS|OKLAHOMA_CITY_THUNDER|GOLDEN_STATE_WARRIORS|0|3|S. Curry makes 3-pt jump shot from 24 ft (assist by K. Durant)",
    "1|673.00|OKLAHOMA_CITY_THUNDER|OKLAHOMA_CITY_THUNDER|GOLDEN_STATE_WARRIORS|0|3|S. Adams misses 2-pt jump shot from 12 ft",

]

game_summary = analyse_nba_game(play_by_play_moves)
print_nba_game_stats(game_summary)